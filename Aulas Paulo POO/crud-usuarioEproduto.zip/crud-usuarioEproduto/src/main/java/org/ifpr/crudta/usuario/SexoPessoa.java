package org.ifpr.crudta.usuario;

public enum SexoPessoa {
    MASCULINO,
    FEMININO,
    OUTRO
}

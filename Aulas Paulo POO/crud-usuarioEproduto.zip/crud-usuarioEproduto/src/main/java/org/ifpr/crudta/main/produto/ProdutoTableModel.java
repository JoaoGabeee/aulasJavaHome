/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.ifpr.crudta.main.produto;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import org.ifpr.crudta.main.produto.dao.ProdutoDAO;
import org.ifpr.crudta.usuario.dao.UsuarioDAO;

/**
 *
 * @author IFPR
 */
public class ProdutoTableModel extends AbstractTableModel {
    
    private final ProdutoDAO produtoDAO;
    private final String[] columnNames;
    private List<Produto> produtos;
    
    public ProdutoTableModel() {
        this.produtoDAO = new ProdutoDAO();
        this.produtos = produtoDAO.listLastTwenty();
        this.columnNames = new String[]{"ID", "NOME", "MARCA", "DATA DE FABRICAÇÃO", "PRECO"};
    }

    public void atualizarTabela() {
        produtos = produtoDAO.listLastTwenty();
        fireTableDataChanged();
    }
    
    public void pesquisarPorNome(String nome) {
        produtos = produtoDAO.pesquisarPorNome(nome);
        fireTableDataChanged();
    }
    
    @Override
    public int getRowCount() {
        return produtos.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Produto produto = produtos.get(rowIndex);
    
        if(columnIndex == 0) {
            return produto.getId();
        }
        
        if(columnIndex == 1) {
            return produto.getNome();
        }
        
        if(columnIndex == 2) {
            return produto.getMarca();
        }
        
        if(columnIndex == 3) {
            return produto.getDataFabricacao();
        }
        
        if(columnIndex == 4) {
            return produto.getPreco();        
        }
        
        return null;
            
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
    
}

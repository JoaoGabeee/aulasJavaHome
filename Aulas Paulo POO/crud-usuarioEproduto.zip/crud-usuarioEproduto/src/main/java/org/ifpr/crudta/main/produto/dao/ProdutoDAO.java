/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.ifpr.crudta.main.produto.dao;

import jakarta.persistence.Query;
import java.util.List;
import org.ifpr.crudta.banco.GenericDAO;
import org.ifpr.crudta.main.produto.Produto;

/**
 *
 * @author IFPR
 */
public class ProdutoDAO extends GenericDAO<Produto>{
    
    public ProdutoDAO() {
        super(Produto.class);
    }
    
    @SuppressWarnings("unchecked")
    public List<Produto> listLastTwenty() {
        entityManager.clear();
        String hqlList = "from Produto p order by p.id desc";
        Query query = entityManager.createQuery(hqlList);
        query.setMaxResults(20);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    public List<Produto> pesquisarPorNome(String nome) {
        String hqlSearch = "from Produto p where lower(p.nome) like concat('%', :nome, '%') order by p.nome asc";
        Query query = entityManager.createQuery(hqlSearch);
        query.setParameter("nome", nome);
        return query.getResultList();
    }
    
}
